﻿Public Class HotelBooking

    Private Sub BtnBook_Click(sender As Object, e As EventArgs) Handles BtnBook.Click
        Dim newdata As New sendData
        newdata.setName = txtNama.Text
        newdata.setPhone = txtPhone.Text
        newdata.setdate = Datepicker.Text
        newdata.setroom = RoomDropdown.Text
        If (newdata.setName = "") Then
            MessageBox.Show("Please insert all field", "Error")
        ElseIf (newdata.setPhone = "") Then
            MessageBox.Show("Please insert all field", "Error")
        Else
            MessageBox.Show("Booking Succesful", "Success")
        End If

        lblName.Text = newdata.getname
        lblPhone.Text = newdata.getphone
        lblDate.Text = newdata.getdate
        lblRoom.Text = newdata.getroom
    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click
        txtNama.Text = ""
        txtPhone.Text = ""
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PrintDialog1.Document = PrintDocument1
        PrintDialog1.PrinterSettings = PrintDocument1.PrinterSettings
        PrintDialog1.AllowSomePages = True

        If PrintDialog1.ShowDialog = DialogResult Then
            PrintDocument1.PrinterSettings = PrintDialog1.PrinterSettings
            PrintDocument1.Print()
        End If
    End Sub

    Private Sub UndoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UndoToolStripMenuItem.Click
        'Undo inside the textbox
        txtNama.Undo()
        txtPhone.Undo()
    End Sub


End Class
Public Class sendData
    Private name As String
    Private phone As String
    Private tdate As String
    Private room As String

    Public Property setName() As String
        Get
            Return name
        End Get
        Set(n As String)
            name = n
        End Set
    End Property
    Public Property setPhone() As String
        Get
            Return phone
        End Get
        Set(p As String)
            phone = p
        End Set
    End Property
    Public Property setdate() As String
        Get
            Return tdate
        End Get
        Set(d As String)
            tdate = d
        End Set
    End Property
    Public Property setroom() As String
        Get
            Return room
        End Get
        Set(r As String)
            room = r
        End Set
    End Property

    Function getname() As String
        Return name
    End Function
    Function getphone() As String
        Return phone
    End Function
    Function getdate() As String
        Return tdate
    End Function
    Function getroom() As String
        Return room
    End Function
End Class
